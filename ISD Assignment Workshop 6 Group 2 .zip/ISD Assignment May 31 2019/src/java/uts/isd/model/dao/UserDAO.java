/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.isd.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.text.*;
import Model.User;

/**
 *
 * @author Patricia Ann Acosta
 */
public class UserDAO {

    private String jdbcURL;
    private String jdbcUsername;
    private String jdbcPassword;
    private Connection jdbcConnection;

    public UserDAO(String jdbcURL, String jdbcUsername, String jdbcPassword) {
        this.jdbcURL = "jdbc:derby://localhost:1527/onlinemoviestore"; //jdbcURL;
        this.jdbcUsername = "adminstaff";  //jdbcUsername;
        this.jdbcPassword = "adminstaff123"; //jdbcPassword;       
    }

    protected void connect() throws SQLException {
        if (jdbcConnection == null || jdbcConnection.isClosed()) {
            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            jdbcConnection = DriverManager.getConnection(
                    jdbcURL, jdbcUsername, jdbcPassword);
            jdbcConnection.setAutoCommit(true);
        }
    }

    protected void disconnect() throws SQLException {
        if (jdbcConnection != null && !jdbcConnection.isClosed()) {
            jdbcConnection.close();
        }
    }

    public boolean insertUser(User user) throws SQLException {
        String sql = "INSERT INTO OMVUSER\n"
                + "(FULL_NAME, PHONE_NUMBER, USERNAME, PASSWORD, STATUS, ROLE)\n"
                + " VALUES(?, ?, ?, ?, ?, ?)";

        boolean rowInserted = false;
        connect();

        PreparedStatement statement = null;

        try {
            statement = jdbcConnection.prepareStatement(sql);
            statement.setString(2, user.getPhoneNumber());
            statement.setString(3, user.getUsername());
            statement.setString(4, user.getPassword());
            statement.setString(5, user.getStatus());
            statement.setString(6, user.getRole());
            statement.setString(1, user.getFullName());
            rowInserted = statement.executeUpdate() > 0;

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) { /* ignored */

                }
            }
            disconnect();
        }
        return rowInserted;
    }

    public List<User> listAllUsers() throws SQLException {
        List<User> listUser = new ArrayList<>();

        String sql = "SELECT * FROM OMVUSER";
        connect();
        Statement statement = null;
        ResultSet resultSet = null;
                
        try {
            statement = jdbcConnection.createStatement();
            resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                String FullName = resultSet.getString("FULL_NAME");
                String PhoneNumber = resultSet.getString("PHONE_NUMBER");
                String UserName = resultSet.getString("USERNAME");
                String Password = resultSet.getString("PASSWORD");
                String Status = resultSet.getString("STATUS");
                String Role = resultSet.getString("ROLE");

                User user = new User(FullName, PhoneNumber, UserName, Password, Status, Role);
                listUser.add(user);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) { /* ignored */
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) { /* ignored */

                }
            }
           }
        disconnect();
        return listUser;
    }

    public boolean deleteUser(User user) throws SQLException {
        String sql = "DELETE FROM OMVUSER WHERE USERNAME = ?";

        boolean rowDeleted = false;
        connect();
        PreparedStatement statement = null;
        try {
            statement = jdbcConnection.prepareStatement(sql);
            statement.setString(1, user.getUsername());

            rowDeleted = statement.executeUpdate() > 0;
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
               if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) { /* ignored */

                }
            }
            disconnect();
        }
            
        return rowDeleted;
    }

    

    public boolean updateUser(User user) throws SQLException {
        String sql = "UPDATE OMVUSER SET FULL_NAME = ?, PHONE_NUMBER = ?, PASSWORD = ?, STATUS = ?, ROLE = ?";
        sql += " WHERE USERNAME = ?";
        
        boolean rowUpdated = false;
        connect();
        PreparedStatement statement = null;
        ResultSet resultSet = null;
 
        try {
            statement = jdbcConnection.prepareStatement(sql);
            statement.setString(1, user.getFullName());
            statement.setString(2, user.getPhoneNumber());
            statement.setString(3, user.getPassword());
            statement.setString(4, user.getStatus());
            statement.setString(5, user.getRole());
            statement.setString(6, user.getUsername());

            rowUpdated = statement.executeUpdate() > 0;
         
            } catch (SQLException ex) {
                  ex.printStackTrace();
                  } finally {
                      if (resultSet != null) {
                          try {
                              resultSet.close();
                          } catch (SQLException e) { /* ignored */
                            }
                       }
                       if (statement != null) {
                           try {
                               statement.close();
                           } catch (SQLException e) { /* ignored */
                             }
                       }
                    }
        
        disconnect();
        return rowUpdated;
    }


      
    public List<User> getUser(String Uname) throws SQLException {
        List<User> eUser = new ArrayList<>();

        String sql = "SELECT * FROM OMVUSER WHERE USERNAME = ?";

        connect();
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        
        try {
            statement = jdbcConnection.prepareStatement(sql);
            statement.setString(1, Uname);

            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String FullName = resultSet.getString("FULL_NAME");
                String PhoneNumber = resultSet.getString("PHONE_NUMBER");
                String UserName = resultSet.getString("USERNAME");
                String Password = resultSet.getString("PASSWORD");
                String Status = resultSet.getString("STATUS");
                String Role = resultSet.getString("ROLE");

                User user = new User(FullName, PhoneNumber, UserName, Password, Status, Role);
                eUser.add(user);

                }
              } catch (SQLException ex) {
                  ex.printStackTrace();
                  } finally {
                      if (resultSet != null) {
                          try {
                              resultSet.close();
                          } catch (SQLException e) { /* ignored */
                            }
                       }
                       if (statement != null) {
                           try {
                               statement.close();
                           } catch (SQLException e) { /* ignored */
                             }
                       }
                    }
        disconnect();
                
        return eUser;
    }
}
