  package uts.isd.model.dao;

import uts.isd.model.User;

import java.sql.*;
import java.util.Arrays;
import java.util.List;


/**
 *
 * @author Khubyeb
 * 
 * DBManager is the primary DAO class to interact with the database and perform CRUD operations with the db.
 * Firstly, complete the existing methods and implement them into the application.
 * 
 * So far the application uses the Read and Create operations in the view.
 * Secondly, improve the current view to enable the Update and Delete operations.
 */
public class DBManager {

    private Statement st;
    
    
    public DBManager(Connection conn) throws SQLException {
        st = conn.createStatement();
    }

    
    public List<User> getUserLogs(String userID) throws SQLException, ClassNotFoundException{
        
       String getQueryString = "select * from ROOT.USERLOGS where ID='" + userID + "'" ;
       DBConnector con =  new DBConnector();
               con.openConnection();
        ResultSet rs = st.executeQuery(getQueryString);
       
        User userLog = new User();
         List <User> userLogsList = Arrays.asList(userLog);
        if (!rs.next()){
        
           System.out.println("Logs not found");
           return null;
        
        
        }
        else
        {
            while (rs.next())
            {
                userLog = new User();
                userLog.setUserID(rs.getString(1));
                userLog.setAction(rs.getString(2));
                userLog.setDate(rs.getString(3));
                userLog.setTime(rs.getString(4));
             
                userLogsList.add(userLog);
                
            }
            
            
        }
        rs.close();
        return userLogsList;
        
        }
    
    
    
    
    public User FindLogs(String userID, String action, String date) throws SQLException, ClassNotFoundException{
   
       String searchQueryString = "select * from ROOT.USERLOGS where ID='" + userID + "' AND Action ='" + action + "' AND DATE='"+ date+ "'";
       DBConnector con =  new DBConnector();
               con.openConnection();
//execute this query using the statement field
       //add the results to a ResultSet
         ResultSet rs = st.executeQuery(searchQueryString);
        //search the ResultSet for a student using the parameters
         boolean hasLogs = rs.next();
         User logFromDB = null;
                 
         if(hasLogs){
         
             userID = rs.getString(1);
             action = rs.getString(2); 
             date = rs.getString(3);
             String time = rs.getString(4);
             
            
             
             logFromDB = new User (userID, action, date, time);
         }
        
         rs.close();
        // st.close();
         
         return logFromDB;
    
    }
    
    //delete a student from the database
    public void deleteDate(String userID) throws SQLException, ClassNotFoundException{
      
      
      
      String deleteQueryString = "delete from ROOT.USERLOGS where ID= '" + userID + "' ";
      DBConnector con =  new DBConnector();
               con.openConnection();
        boolean recrodDeleted = st.executeUpdate(deleteQueryString) > 0;
         
         if (recrodDeleted){
         System.out.println("record deleted");
         }
         else {
         System.out.println("record not deleted");
         }
    };
    
    public void addLogs(String ID, String action, String date, String time  )throws SQLException, ClassNotFoundException {        
        //code for add-operation
        
         String createQueryString = "insert into ROOT.USERLOGS" + " values ('" + ID + "', '" + action + "', '" + date + "', '" + time + "')";
         DBConnector con =  new DBConnector();
               con.openConnection();
         boolean recrodCreated = st.executeUpdate(createQueryString) > 0;
         
         if (recrodCreated){
         System.out.println("record created");
         }
         else {
         System.out.println("record not created");
         }
             
    }
}
